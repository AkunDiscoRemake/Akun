package com.akundisco.optimizer

import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OptimizationActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pkg = intent.getStringExtra("PKG") ?: return finish()
        val name = intent.getStringExtra("NAME") ?: "Jogo"

        val tv = TextView(this)
        tv.gravity = Gravity.CENTER
        tv.textSize = 16f
        setContentView(tv)

        tv.text = "Otimizando $name...
Aguarde"

        Handler(Looper.getMainLooper()).postDelayed({
            boostSystem(pkg)
            launch(pkg)
        }, 2000)
    }

    private fun boostSystem(target: String) {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.runningAppProcesses?.forEach {
            if (it.importance > ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
                && it.processName != target) {
                am.killBackgroundProcesses(it.processName)
            }
        }
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            finishAffinity()
        }
    }
}
