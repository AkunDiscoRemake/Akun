package com.akundisco.optimizer

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class AppSelectionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }

        val names = apps.map { pm.getApplicationLabel(it).toString() }
        val list = ListView(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)

        list.setOnItemClickListener { _, _, i, _ ->
            startActivity(
                Intent(this, OptimizationActivity::class.java)
                    .putExtra("PKG", apps[i].packageName)
                    .putExtra("NAME", names[i])
            )
            finish()
        }

        setContentView(list)
    }
}
